package eu.lod2.nlp2rdf.schema.tools;

import java.util.ArrayList;
import java.util.List;

import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.rdf.model.*;

/**
 * A vocabulary for all properties, classes etc. used
 * in the ontology. This is based on the jena schemagen
 * output
 *
 * Note, that the current implementation assumes unique names
 * for class names.
 */
public class Vocabulary {
	public static final List<java.lang.String> NAMESPACES;

	public static final Resource NSSTR;
	public static final Resource NSP1;
	public static final Resource NS;

	public static final OntClass Thing;
	public static final OntClass Word;
	public static final OntClass Phrase;
	public static final OntClass Document;
	public static final OntClass Sentence;
	public static final OntClass String;

	public static final ObjectProperty word;
	public static final ObjectProperty superString;
	public static final ObjectProperty nextWord;
	public static final ObjectProperty lastWord;
	public static final ObjectProperty subString;
	public static final ObjectProperty sentence;
	public static final DatatypeProperty sourceString;
	public static final DatatypeProperty anchorOf;
	public static final ObjectProperty previousWord;
	public static final ObjectProperty nextWordTrans;
	public static final ObjectProperty previousWordTrans;
	public static final ObjectProperty firstWord;
	public static final ObjectProperty subStringTrans;
	public static final ObjectProperty superStringTrans;
	public static final ObjectProperty sourceUrl;

	static {
		NAMESPACES = new ArrayList<java.lang.String>();
		NAMESPACES.add("http://nlp2rdf.lod2.eu/schema/string/");
		NAMESPACES.add("http://nlp2rdf.lod2.eu/schema/string/#");
		NAMESPACES.add("http://nlp2rdf.lod2.eu/schema/sso/");

		OntModel resourceModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM, null);

		NSSTR = resourceModel.createResource("http://nlp2rdf.lod2.eu/schema/string/");
		NSP1 = resourceModel.createResource("http://nlp2rdf.lod2.eu/schema/string/#");
		NS = resourceModel.createResource("http://nlp2rdf.lod2.eu/schema/sso/");

		Thing = resourceModel.createClass("http://www.w3.org/2002/07/owl#Thing");
		Word = resourceModel.createClass("http://nlp2rdf.lod2.eu/schema/sso/Word");
		Phrase = resourceModel.createClass("http://nlp2rdf.lod2.eu/schema/sso/Phrase");
		Document = resourceModel.createClass("http://nlp2rdf.lod2.eu/schema/string/Document");
		Sentence = resourceModel.createClass("http://nlp2rdf.lod2.eu/schema/sso/Sentence");
		String = resourceModel.createClass("http://nlp2rdf.lod2.eu/schema/string/String");

		word = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/word");
		superString = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/string/superString");
		nextWord = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/nextWord");
		lastWord = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/lastWord");
		subString = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/string/subString");
		sentence = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/sentence");
		sourceString = resourceModel.createDatatypeProperty("http://nlp2rdf.lod2.eu/schema/string/sourceString");
		anchorOf = resourceModel.createDatatypeProperty("http://nlp2rdf.lod2.eu/schema/string/anchorOf");
		previousWord = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/previousWord");
		nextWordTrans = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/nextWordTrans");
		previousWordTrans = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/previousWordTrans");
		firstWord = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/sso/firstWord");
		subStringTrans = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/string/subStringTrans");
		superStringTrans = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/string/superStringTrans");
		sourceUrl = resourceModel.createObjectProperty("http://nlp2rdf.lod2.eu/schema/string/sourceUrl");
	}
}
