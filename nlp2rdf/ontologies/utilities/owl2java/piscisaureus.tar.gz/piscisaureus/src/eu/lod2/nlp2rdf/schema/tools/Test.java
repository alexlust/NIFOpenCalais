package eu.lod2.nlp2rdf.schema.tools;

import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.Ontology;
import com.hp.hpl.jena.rdf.model.ModelFactory;

import eu.lod2.nlp2rdf.schema.tools.Factory;

/**
 * Factory
 */
public class Test {

	private static Log log = LogFactory.getLog(Test.class);

	private static java.lang.String namePrefix = "ClassInstance";
	private static int nameCount = 0;

	public static void main(java.lang.String[] args) {
		run();
	}

	private static java.lang.String getNewInstanceName() {
		nameCount++;
		return namePrefix + nameCount;
	}

	private static java.lang.String getNewInstanceURI() {
		java.lang.String localName = getNewInstanceName();
		java.lang.String base = "jmodel.getBaseNamespace()";
		return base + "#" + localName;
	}

	public static void run() {
		java.lang.String base = "jmodel.getBaseNamespace()";

		log.info("Creating an empty ontology");
		OntModel ontModel = ModelFactory.createOntologyModel();
		Ontology ontology = ontModel.createOntology(base);

		log.info("Registering custom classes with jena");
		Factory.registerImports(ontology, ontModel);
		Factory.registerCustomClasses();

		log.info("Starting test case run");
		runThing(ontModel);
		runWord(ontModel);
		runPhrase(ontModel);
		runDocument(ontModel);
		runSentence(ontModel);
		runString(ontModel);
		log.info("DONE DONE DONE DONE DONE DONE DONE DONE");
	}

	protected static void runThing(OntModel ontModel) {
		log.info("Testing class Thing");

		// create, create anonymous, exists, delete, list
		log.debug("  Creating anonymous class instance");
		eu.lod2.nlp2rdf.schema.Thing.create(ontModel);

		log.debug("  Creating two named class instance");
		java.lang.String uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Thing.create(uri, ontModel);
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Thing.create(uri, ontModel);

		log.debug("  Checking for existance of class instance");
		boolean exists = eu.lod2.nlp2rdf.schema.Thing.exists(uri, ontModel);
		log.debug("  -> exists: " + exists);

		log.debug("  Fetching known instance");
		eu.lod2.nlp2rdf.schema.Thing clsInstance = eu.lod2.nlp2rdf.schema.Thing.get(uri, ontModel);
		log.debug("  -> instance: " + clsInstance.getLocalName());

		log.debug("  Iterate over all class instances");
		Iterator<eu.lod2.nlp2rdf.schema.Thing> it = eu.lod2.nlp2rdf.schema.Thing.iterate(ontModel);
		while (it.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Thing) it.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances and ");
		for (eu.lod2.nlp2rdf.schema.Thing cls : eu.lod2.nlp2rdf.schema.Thing.list(ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Iterate over all class instances and subclass instances");
		Iterator<eu.lod2.nlp2rdf.schema.Thing> it2 = eu.lod2.nlp2rdf.schema.Thing.iterate(false, ontModel);
		while (it2.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Thing) it2.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances");
		for (eu.lod2.nlp2rdf.schema.Thing cls : eu.lod2.nlp2rdf.schema.Thing.list(false, ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Counting class instances");
		log.debug("  -> count: " + eu.lod2.nlp2rdf.schema.Thing.count(ontModel));

		log.debug("  Deleting a named class instance");
		eu.lod2.nlp2rdf.schema.Thing.delete(uri, ontModel);

	}

	protected static void runWord(OntModel ontModel) {
		log.info("Testing class Word");

		// create, create anonymous, exists, delete, list
		log.debug("  Creating anonymous class instance");
		eu.lod2.nlp2rdf.schema.Word.create(ontModel);

		log.debug("  Creating two named class instance");
		java.lang.String uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Word.create(uri, ontModel);
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Word.create(uri, ontModel);

		log.debug("  Checking for existance of class instance");
		boolean exists = eu.lod2.nlp2rdf.schema.Word.exists(uri, ontModel);
		log.debug("  -> exists: " + exists);

		log.debug("  Fetching known instance");
		eu.lod2.nlp2rdf.schema.Word clsInstance = eu.lod2.nlp2rdf.schema.Word.get(uri, ontModel);
		log.debug("  -> instance: " + clsInstance.getLocalName());

		log.debug("  Iterate over all class instances");
		Iterator<eu.lod2.nlp2rdf.schema.Word> it = eu.lod2.nlp2rdf.schema.Word.iterate(ontModel);
		while (it.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Word) it.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances and ");
		for (eu.lod2.nlp2rdf.schema.Word cls : eu.lod2.nlp2rdf.schema.Word.list(ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Iterate over all class instances and subclass instances");
		Iterator<eu.lod2.nlp2rdf.schema.Word> it2 = eu.lod2.nlp2rdf.schema.Word.iterate(false, ontModel);
		while (it2.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Word) it2.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances");
		for (eu.lod2.nlp2rdf.schema.Word cls : eu.lod2.nlp2rdf.schema.Word.list(false, ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Counting class instances");
		log.debug("  -> count: " + eu.lod2.nlp2rdf.schema.Word.count(ontModel));

		log.debug("  Deleting a named class instance");
		eu.lod2.nlp2rdf.schema.Word.delete(uri, ontModel);

		// class instance for property tests
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Word.create(uri, ontModel);
		eu.lod2.nlp2rdf.schema.Word instance = eu.lod2.nlp2rdf.schema.Word.get(uri, ontModel);

		// test each representation
		log.info("  Testing property sentence of class Word");

		log.debug("    Any property sentence exist?");
		log.debug("    -> exists: " + instance.existsSentence());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSentence(eu.lod2.nlp2rdf.schema.Sentence.create(uri, ontModel));
		instance.addSentence(eu.lod2.nlp2rdf.schema.Sentence.create(getNewInstanceURI(), ontModel));
		instance.addSentence(eu.lod2.nlp2rdf.schema.Sentence.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.Sentence> itSentence = instance.iterateSentence();
		eu.lod2.nlp2rdf.schema.Sentence instSentence = null;
		while (itSentence.hasNext()) {
			instSentence = (eu.lod2.nlp2rdf.schema.Sentence) itSentence.next();
			log.debug("    -> instance: " + instSentence.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.Sentence iinstSentence : instance.listSentence())
			log.debug("    -> instance: " + iinstSentence.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSentence());

		log.debug("    Removing a known property instance");
		instance.removeSentence(instSentence);

		log.debug("    Removing all property instances");
		instance.removeAllSentence();

		log.info("  Testing property nextWordTrans of class Word");

		log.debug("    Any property nextWordTrans exist?");
		log.debug("    -> exists: " + instance.existsNextWordTrans());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addNextWordTrans(eu.lod2.nlp2rdf.schema.Word.create(uri, ontModel));
		instance.addNextWordTrans(eu.lod2.nlp2rdf.schema.Word.create(getNewInstanceURI(), ontModel));
		instance.addNextWordTrans(eu.lod2.nlp2rdf.schema.Word.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.Word> itNextWordTrans = instance.iterateNextWordTrans();
		eu.lod2.nlp2rdf.schema.Word instNextWordTrans = null;
		while (itNextWordTrans.hasNext()) {
			instNextWordTrans = (eu.lod2.nlp2rdf.schema.Word) itNextWordTrans.next();
			log.debug("    -> instance: " + instNextWordTrans.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.Word iinstNextWordTrans : instance.listNextWordTrans())
			log.debug("    -> instance: " + iinstNextWordTrans.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countNextWordTrans());

		log.debug("    Removing a known property instance");
		instance.removeNextWordTrans(instNextWordTrans);

		log.debug("    Removing all property instances");
		instance.removeAllNextWordTrans();

		log.info("  Testing property subStringTrans of class Word");

		log.debug("    Any property subStringTrans exist?");
		log.debug("    -> exists: " + instance.existsSubStringTrans());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> itSubStringTrans = instance.iterateSubStringTrans();
		eu.lod2.nlp2rdf.schema.str.String instSubStringTrans = null;
		while (itSubStringTrans.hasNext()) {
			instSubStringTrans = (eu.lod2.nlp2rdf.schema.str.String) itSubStringTrans.next();
			log.debug("    -> instance: " + instSubStringTrans.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.str.String iinstSubStringTrans : instance.listSubStringTrans())
			log.debug("    -> instance: " + iinstSubStringTrans.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSubStringTrans());

		log.debug("    Removing a known property instance");
		instance.removeSubStringTrans(instSubStringTrans);

		log.debug("    Removing all property instances");
		instance.removeAllSubStringTrans();

		log.info("  Testing property anchorOf of class Word");

		log.debug("    Any property anchorOf exist?");
		log.debug("    -> exists: " + instance.existsAnchorOf());

		log.debug("    Adding property instance");
		instance.addAnchorOf(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdMapTestData.getString("http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral"));

		log.debug("    Iterate over all property values");
		Iterator<java.lang.String> itAnchorOf = instance.iterateAnchorOf();
		java.lang.String instAnchorOf = null;
		while (itAnchorOf.hasNext()) {
			instAnchorOf = (java.lang.String) itAnchorOf.next();
			log.debug("    -> instance: " + instAnchorOf);
		}

		log.debug("    List all property values");
		for (java.lang.String iinstAnchorOf : instance.listAnchorOf())
			log.debug("    -> instance: " + iinstAnchorOf);

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countAnchorOf());

		log.debug("    Removing a known property instance");
		instance.removeAnchorOf(instAnchorOf);

		log.debug("    Removing all property instances");
		instance.removeAllAnchorOf();

	}

	protected static void runPhrase(OntModel ontModel) {
		log.info("Testing class Phrase");

		// create, create anonymous, exists, delete, list
		log.debug("  Creating anonymous class instance");
		eu.lod2.nlp2rdf.schema.Phrase.create(ontModel);

		log.debug("  Creating two named class instance");
		java.lang.String uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Phrase.create(uri, ontModel);
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Phrase.create(uri, ontModel);

		log.debug("  Checking for existance of class instance");
		boolean exists = eu.lod2.nlp2rdf.schema.Phrase.exists(uri, ontModel);
		log.debug("  -> exists: " + exists);

		log.debug("  Fetching known instance");
		eu.lod2.nlp2rdf.schema.Phrase clsInstance = eu.lod2.nlp2rdf.schema.Phrase.get(uri, ontModel);
		log.debug("  -> instance: " + clsInstance.getLocalName());

		log.debug("  Iterate over all class instances");
		Iterator<eu.lod2.nlp2rdf.schema.Phrase> it = eu.lod2.nlp2rdf.schema.Phrase.iterate(ontModel);
		while (it.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Phrase) it.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances and ");
		for (eu.lod2.nlp2rdf.schema.Phrase cls : eu.lod2.nlp2rdf.schema.Phrase.list(ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Iterate over all class instances and subclass instances");
		Iterator<eu.lod2.nlp2rdf.schema.Phrase> it2 = eu.lod2.nlp2rdf.schema.Phrase.iterate(false, ontModel);
		while (it2.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Phrase) it2.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances");
		for (eu.lod2.nlp2rdf.schema.Phrase cls : eu.lod2.nlp2rdf.schema.Phrase.list(false, ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Counting class instances");
		log.debug("  -> count: " + eu.lod2.nlp2rdf.schema.Phrase.count(ontModel));

		log.debug("  Deleting a named class instance");
		eu.lod2.nlp2rdf.schema.Phrase.delete(uri, ontModel);

		// class instance for property tests
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Phrase.create(uri, ontModel);
		eu.lod2.nlp2rdf.schema.Phrase instance = eu.lod2.nlp2rdf.schema.Phrase.get(uri, ontModel);

		// test each representation
		log.info("  Testing property subStringTrans of class Phrase");

		log.debug("    Any property subStringTrans exist?");
		log.debug("    -> exists: " + instance.existsSubStringTrans());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> itSubStringTrans = instance.iterateSubStringTrans();
		eu.lod2.nlp2rdf.schema.str.String instSubStringTrans = null;
		while (itSubStringTrans.hasNext()) {
			instSubStringTrans = (eu.lod2.nlp2rdf.schema.str.String) itSubStringTrans.next();
			log.debug("    -> instance: " + instSubStringTrans.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.str.String iinstSubStringTrans : instance.listSubStringTrans())
			log.debug("    -> instance: " + iinstSubStringTrans.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSubStringTrans());

		log.debug("    Removing a known property instance");
		instance.removeSubStringTrans(instSubStringTrans);

		log.debug("    Removing all property instances");
		instance.removeAllSubStringTrans();

		log.info("  Testing property anchorOf of class Phrase");

		log.debug("    Any property anchorOf exist?");
		log.debug("    -> exists: " + instance.existsAnchorOf());

		log.debug("    Adding property instance");
		instance.addAnchorOf(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdMapTestData.getString("http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral"));

		log.debug("    Iterate over all property values");
		Iterator<java.lang.String> itAnchorOf = instance.iterateAnchorOf();
		java.lang.String instAnchorOf = null;
		while (itAnchorOf.hasNext()) {
			instAnchorOf = (java.lang.String) itAnchorOf.next();
			log.debug("    -> instance: " + instAnchorOf);
		}

		log.debug("    List all property values");
		for (java.lang.String iinstAnchorOf : instance.listAnchorOf())
			log.debug("    -> instance: " + iinstAnchorOf);

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countAnchorOf());

		log.debug("    Removing a known property instance");
		instance.removeAnchorOf(instAnchorOf);

		log.debug("    Removing all property instances");
		instance.removeAllAnchorOf();

	}

	protected static void runDocument(OntModel ontModel) {
		log.info("Testing class Document");

		// create, create anonymous, exists, delete, list
		log.debug("  Creating anonymous class instance");
		eu.lod2.nlp2rdf.schema.str.Document.create(ontModel);

		log.debug("  Creating two named class instance");
		java.lang.String uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.str.Document.create(uri, ontModel);
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.str.Document.create(uri, ontModel);

		log.debug("  Checking for existance of class instance");
		boolean exists = eu.lod2.nlp2rdf.schema.str.Document.exists(uri, ontModel);
		log.debug("  -> exists: " + exists);

		log.debug("  Fetching known instance");
		eu.lod2.nlp2rdf.schema.str.Document clsInstance = eu.lod2.nlp2rdf.schema.str.Document.get(uri, ontModel);
		log.debug("  -> instance: " + clsInstance.getLocalName());

		log.debug("  Iterate over all class instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.Document> it = eu.lod2.nlp2rdf.schema.str.Document.iterate(ontModel);
		while (it.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.str.Document) it.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances and ");
		for (eu.lod2.nlp2rdf.schema.str.Document cls : eu.lod2.nlp2rdf.schema.str.Document.list(ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Iterate over all class instances and subclass instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.Document> it2 = eu.lod2.nlp2rdf.schema.str.Document.iterate(false, ontModel);
		while (it2.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.str.Document) it2.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances");
		for (eu.lod2.nlp2rdf.schema.str.Document cls : eu.lod2.nlp2rdf.schema.str.Document.list(false, ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Counting class instances");
		log.debug("  -> count: " + eu.lod2.nlp2rdf.schema.str.Document.count(ontModel));

		log.debug("  Deleting a named class instance");
		eu.lod2.nlp2rdf.schema.str.Document.delete(uri, ontModel);

		// class instance for property tests
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.str.Document.create(uri, ontModel);
		eu.lod2.nlp2rdf.schema.str.Document instance = eu.lod2.nlp2rdf.schema.str.Document.get(uri, ontModel);

		// test each representation
		log.info("  Testing property sourceUrl of class Document");

		log.debug("    Any property sourceUrl exist?");
		log.debug("    -> exists: " + instance.existsSourceUrl());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSourceUrl(eu.lod2.nlp2rdf.schema.Thing.create(uri, ontModel));
		instance.addSourceUrl(eu.lod2.nlp2rdf.schema.Thing.create(getNewInstanceURI(), ontModel));
		instance.addSourceUrl(eu.lod2.nlp2rdf.schema.Thing.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.Thing> itSourceUrl = instance.iterateSourceUrl();
		eu.lod2.nlp2rdf.schema.Thing instSourceUrl = null;
		while (itSourceUrl.hasNext()) {
			instSourceUrl = (eu.lod2.nlp2rdf.schema.Thing) itSourceUrl.next();
			log.debug("    -> instance: " + instSourceUrl.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.Thing iinstSourceUrl : instance.listSourceUrl())
			log.debug("    -> instance: " + iinstSourceUrl.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSourceUrl());

		log.debug("    Removing a known property instance");
		instance.removeSourceUrl(instSourceUrl);

		log.debug("    Removing all property instances");
		instance.removeAllSourceUrl();

		log.info("  Testing property sourceString of class Document");

		log.debug("    Any property sourceString exist?");
		log.debug("    -> exists: " + instance.existsSourceString());

		log.debug("    Adding property instance");
		instance.addSourceString(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdMapTestData.getString("http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral"));

		log.debug("    Iterate over all property values");
		Iterator<java.lang.String> itSourceString = instance.iterateSourceString();
		java.lang.String instSourceString = null;
		while (itSourceString.hasNext()) {
			instSourceString = (java.lang.String) itSourceString.next();
			log.debug("    -> instance: " + instSourceString);
		}

		log.debug("    List all property values");
		for (java.lang.String iinstSourceString : instance.listSourceString())
			log.debug("    -> instance: " + iinstSourceString);

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSourceString());

		log.debug("    Removing a known property instance");
		instance.removeSourceString(instSourceString);

		log.debug("    Removing all property instances");
		instance.removeAllSourceString();

		log.info("  Testing property subStringTrans of class Document");

		log.debug("    Any property subStringTrans exist?");
		log.debug("    -> exists: " + instance.existsSubStringTrans());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> itSubStringTrans = instance.iterateSubStringTrans();
		eu.lod2.nlp2rdf.schema.str.String instSubStringTrans = null;
		while (itSubStringTrans.hasNext()) {
			instSubStringTrans = (eu.lod2.nlp2rdf.schema.str.String) itSubStringTrans.next();
			log.debug("    -> instance: " + instSubStringTrans.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.str.String iinstSubStringTrans : instance.listSubStringTrans())
			log.debug("    -> instance: " + iinstSubStringTrans.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSubStringTrans());

		log.debug("    Removing a known property instance");
		instance.removeSubStringTrans(instSubStringTrans);

		log.debug("    Removing all property instances");
		instance.removeAllSubStringTrans();

		log.info("  Testing property anchorOf of class Document");

		log.debug("    Any property anchorOf exist?");
		log.debug("    -> exists: " + instance.existsAnchorOf());

		log.debug("    Adding property instance");
		instance.addAnchorOf(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdMapTestData.getString("http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral"));

		log.debug("    Iterate over all property values");
		Iterator<java.lang.String> itAnchorOf = instance.iterateAnchorOf();
		java.lang.String instAnchorOf = null;
		while (itAnchorOf.hasNext()) {
			instAnchorOf = (java.lang.String) itAnchorOf.next();
			log.debug("    -> instance: " + instAnchorOf);
		}

		log.debug("    List all property values");
		for (java.lang.String iinstAnchorOf : instance.listAnchorOf())
			log.debug("    -> instance: " + iinstAnchorOf);

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countAnchorOf());

		log.debug("    Removing a known property instance");
		instance.removeAnchorOf(instAnchorOf);

		log.debug("    Removing all property instances");
		instance.removeAllAnchorOf();

	}

	protected static void runSentence(OntModel ontModel) {
		log.info("Testing class Sentence");

		// create, create anonymous, exists, delete, list
		log.debug("  Creating anonymous class instance");
		eu.lod2.nlp2rdf.schema.Sentence.create(ontModel);

		log.debug("  Creating two named class instance");
		java.lang.String uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Sentence.create(uri, ontModel);
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Sentence.create(uri, ontModel);

		log.debug("  Checking for existance of class instance");
		boolean exists = eu.lod2.nlp2rdf.schema.Sentence.exists(uri, ontModel);
		log.debug("  -> exists: " + exists);

		log.debug("  Fetching known instance");
		eu.lod2.nlp2rdf.schema.Sentence clsInstance = eu.lod2.nlp2rdf.schema.Sentence.get(uri, ontModel);
		log.debug("  -> instance: " + clsInstance.getLocalName());

		log.debug("  Iterate over all class instances");
		Iterator<eu.lod2.nlp2rdf.schema.Sentence> it = eu.lod2.nlp2rdf.schema.Sentence.iterate(ontModel);
		while (it.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Sentence) it.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances and ");
		for (eu.lod2.nlp2rdf.schema.Sentence cls : eu.lod2.nlp2rdf.schema.Sentence.list(ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Iterate over all class instances and subclass instances");
		Iterator<eu.lod2.nlp2rdf.schema.Sentence> it2 = eu.lod2.nlp2rdf.schema.Sentence.iterate(false, ontModel);
		while (it2.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.Sentence) it2.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances");
		for (eu.lod2.nlp2rdf.schema.Sentence cls : eu.lod2.nlp2rdf.schema.Sentence.list(false, ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Counting class instances");
		log.debug("  -> count: " + eu.lod2.nlp2rdf.schema.Sentence.count(ontModel));

		log.debug("  Deleting a named class instance");
		eu.lod2.nlp2rdf.schema.Sentence.delete(uri, ontModel);

		// class instance for property tests
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.Sentence.create(uri, ontModel);
		eu.lod2.nlp2rdf.schema.Sentence instance = eu.lod2.nlp2rdf.schema.Sentence.get(uri, ontModel);

		// test each representation
		log.info("  Testing property word of class Sentence");

		log.debug("    Any property word exist?");
		log.debug("    -> exists: " + instance.existsWord());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addWord(eu.lod2.nlp2rdf.schema.Word.create(uri, ontModel));
		instance.addWord(eu.lod2.nlp2rdf.schema.Word.create(getNewInstanceURI(), ontModel));
		instance.addWord(eu.lod2.nlp2rdf.schema.Word.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.Word> itWord = instance.iterateWord();
		eu.lod2.nlp2rdf.schema.Word instWord = null;
		while (itWord.hasNext()) {
			instWord = (eu.lod2.nlp2rdf.schema.Word) itWord.next();
			log.debug("    -> instance: " + instWord.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.Word iinstWord : instance.listWord())
			log.debug("    -> instance: " + iinstWord.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countWord());

		log.debug("    Removing a known property instance");
		instance.removeWord(instWord);

		log.debug("    Removing all property instances");
		instance.removeAllWord();

		log.info("  Testing property subStringTrans of class Sentence");

		log.debug("    Any property subStringTrans exist?");
		log.debug("    -> exists: " + instance.existsSubStringTrans());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> itSubStringTrans = instance.iterateSubStringTrans();
		eu.lod2.nlp2rdf.schema.str.String instSubStringTrans = null;
		while (itSubStringTrans.hasNext()) {
			instSubStringTrans = (eu.lod2.nlp2rdf.schema.str.String) itSubStringTrans.next();
			log.debug("    -> instance: " + instSubStringTrans.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.str.String iinstSubStringTrans : instance.listSubStringTrans())
			log.debug("    -> instance: " + iinstSubStringTrans.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSubStringTrans());

		log.debug("    Removing a known property instance");
		instance.removeSubStringTrans(instSubStringTrans);

		log.debug("    Removing all property instances");
		instance.removeAllSubStringTrans();

		log.info("  Testing property anchorOf of class Sentence");

		log.debug("    Any property anchorOf exist?");
		log.debug("    -> exists: " + instance.existsAnchorOf());

		log.debug("    Adding property instance");
		instance.addAnchorOf(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdMapTestData.getString("http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral"));

		log.debug("    Iterate over all property values");
		Iterator<java.lang.String> itAnchorOf = instance.iterateAnchorOf();
		java.lang.String instAnchorOf = null;
		while (itAnchorOf.hasNext()) {
			instAnchorOf = (java.lang.String) itAnchorOf.next();
			log.debug("    -> instance: " + instAnchorOf);
		}

		log.debug("    List all property values");
		for (java.lang.String iinstAnchorOf : instance.listAnchorOf())
			log.debug("    -> instance: " + iinstAnchorOf);

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countAnchorOf());

		log.debug("    Removing a known property instance");
		instance.removeAnchorOf(instAnchorOf);

		log.debug("    Removing all property instances");
		instance.removeAllAnchorOf();

	}

	protected static void runString(OntModel ontModel) {
		log.info("Testing class String");

		// create, create anonymous, exists, delete, list
		log.debug("  Creating anonymous class instance");
		eu.lod2.nlp2rdf.schema.str.String.create(ontModel);

		log.debug("  Creating two named class instance");
		java.lang.String uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel);
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel);

		log.debug("  Checking for existance of class instance");
		boolean exists = eu.lod2.nlp2rdf.schema.str.String.exists(uri, ontModel);
		log.debug("  -> exists: " + exists);

		log.debug("  Fetching known instance");
		eu.lod2.nlp2rdf.schema.str.String clsInstance = eu.lod2.nlp2rdf.schema.str.String.get(uri, ontModel);
		log.debug("  -> instance: " + clsInstance.getLocalName());

		log.debug("  Iterate over all class instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> it = eu.lod2.nlp2rdf.schema.str.String.iterate(ontModel);
		while (it.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.str.String) it.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances and ");
		for (eu.lod2.nlp2rdf.schema.str.String cls : eu.lod2.nlp2rdf.schema.str.String.list(ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Iterate over all class instances and subclass instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> it2 = eu.lod2.nlp2rdf.schema.str.String.iterate(false, ontModel);
		while (it2.hasNext()) {
			clsInstance = (eu.lod2.nlp2rdf.schema.str.String) it2.next();
			log.debug("  -> instance: " + clsInstance.getLocalName());
		}

		log.debug("  List all class instances");
		for (eu.lod2.nlp2rdf.schema.str.String cls : eu.lod2.nlp2rdf.schema.str.String.list(false, ontModel))
			log.debug("  -> instance: " + cls.getLocalName());

		log.debug("  Counting class instances");
		log.debug("  -> count: " + eu.lod2.nlp2rdf.schema.str.String.count(ontModel));

		log.debug("  Deleting a named class instance");
		eu.lod2.nlp2rdf.schema.str.String.delete(uri, ontModel);

		// class instance for property tests
		uri = getNewInstanceURI();
		eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel);
		eu.lod2.nlp2rdf.schema.str.String instance = eu.lod2.nlp2rdf.schema.str.String.get(uri, ontModel);

		// test each representation
		log.info("  Testing property subStringTrans of class String");

		log.debug("    Any property subStringTrans exist?");
		log.debug("    -> exists: " + instance.existsSubStringTrans());

		log.debug("    Adding property instance");
		uri = getNewInstanceURI();
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(uri, ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));
		instance.addSubStringTrans(eu.lod2.nlp2rdf.schema.str.String.create(getNewInstanceURI(), ontModel));

		log.debug("    Iterate over all property instances");
		Iterator<eu.lod2.nlp2rdf.schema.str.String> itSubStringTrans = instance.iterateSubStringTrans();
		eu.lod2.nlp2rdf.schema.str.String instSubStringTrans = null;
		while (itSubStringTrans.hasNext()) {
			instSubStringTrans = (eu.lod2.nlp2rdf.schema.str.String) itSubStringTrans.next();
			log.debug("    -> instance: " + instSubStringTrans.getLocalName());
		}

		log.debug("    List all property values");
		for (eu.lod2.nlp2rdf.schema.str.String iinstSubStringTrans : instance.listSubStringTrans())
			log.debug("    -> instance: " + iinstSubStringTrans.getLocalName());

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countSubStringTrans());

		log.debug("    Removing a known property instance");
		instance.removeSubStringTrans(instSubStringTrans);

		log.debug("    Removing all property instances");
		instance.removeAllSubStringTrans();

		log.info("  Testing property anchorOf of class String");

		log.debug("    Any property anchorOf exist?");
		log.debug("    -> exists: " + instance.existsAnchorOf());

		log.debug("    Adding property instance");
		instance.addAnchorOf(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdMapTestData.getString("http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral"));

		log.debug("    Iterate over all property values");
		Iterator<java.lang.String> itAnchorOf = instance.iterateAnchorOf();
		java.lang.String instAnchorOf = null;
		while (itAnchorOf.hasNext()) {
			instAnchorOf = (java.lang.String) itAnchorOf.next();
			log.debug("    -> instance: " + instAnchorOf);
		}

		log.debug("    List all property values");
		for (java.lang.String iinstAnchorOf : instance.listAnchorOf())
			log.debug("    -> instance: " + iinstAnchorOf);

		log.debug("    Count property values");
		log.debug("    -> count: " + instance.countAnchorOf());

		log.debug("    Removing a known property instance");
		instance.removeAnchorOf(instAnchorOf);

		log.debug("    Removing all property instances");
		instance.removeAllAnchorOf();

	}
}
