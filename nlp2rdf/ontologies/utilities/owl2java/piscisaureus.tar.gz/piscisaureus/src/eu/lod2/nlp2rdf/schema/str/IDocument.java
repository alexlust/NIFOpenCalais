package eu.lod2.nlp2rdf.schema.str;

import java.util.List;
import java.util.Iterator;

import com.hp.hpl.jena.ontology.Individual;

/**
 * Interface http://nlp2rdf.lod2.eu/schema/string/Document
 */

public interface IDocument extends Individual, eu.lod2.nlp2rdf.schema.str.IString {

	/**
	 * Domain property SourceUrl
	 * with uri http://nlp2rdf.lod2.eu/schema/string/sourceUrl
	 */

	public boolean existsSourceUrl();

	public boolean hasSourceUrl(eu.lod2.nlp2rdf.schema.IThing thingValue);

	public int countSourceUrl();

	public Iterator<eu.lod2.nlp2rdf.schema.Thing> iterateSourceUrl();

	public List<eu.lod2.nlp2rdf.schema.Thing> listSourceUrl();

	public void addSourceUrl(eu.lod2.nlp2rdf.schema.IThing thingValue);

	public void addAllSourceUrl(List<? extends eu.lod2.nlp2rdf.schema.IThing> thingList);

	public void removeSourceUrl(eu.lod2.nlp2rdf.schema.IThing thingValue);

	public void removeAllSourceUrl();

	/**
	 * Domain property SourceString
	 * with uri http://nlp2rdf.lod2.eu/schema/string/sourceString
	 */

	public boolean existsSourceString();

	public boolean hasSourceString(java.lang.String stringValue);

	public int countSourceString();

	public Iterator<java.lang.String> iterateSourceString();

	public List<java.lang.String> listSourceString();

	public void addSourceString(java.lang.String stringValue);

	public void addAllSourceString(List<java.lang.String> stringList);

	public void removeSourceString(java.lang.String stringValue);

	public void removeAllSourceString();

	/**
	 * Domain property SubStringTrans
	 * with uri http://nlp2rdf.lod2.eu/schema/string/subStringTrans
	 */

	public boolean existsSubStringTrans();

	public boolean hasSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue);

	public int countSubStringTrans();

	public Iterator<eu.lod2.nlp2rdf.schema.str.String> iterateSubStringTrans();

	public List<eu.lod2.nlp2rdf.schema.str.String> listSubStringTrans();

	public void addSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue);

	public void addAllSubStringTrans(List<? extends eu.lod2.nlp2rdf.schema.str.IString> stringList);

	public void removeSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue);

	public void removeAllSubStringTrans();

	/**
	 * Domain property AnchorOf
	 * with uri http://nlp2rdf.lod2.eu/schema/string/anchorOf
	 */

	public boolean existsAnchorOf();

	public boolean hasAnchorOf(java.lang.String stringValue);

	public int countAnchorOf();

	public Iterator<java.lang.String> iterateAnchorOf();

	public List<java.lang.String> listAnchorOf();

	public void addAnchorOf(java.lang.String stringValue);

	public void addAllAnchorOf(List<java.lang.String> stringList);

	public void removeAnchorOf(java.lang.String stringValue);

	public void removeAllAnchorOf();

}