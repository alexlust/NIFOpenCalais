package eu.lod2.nlp2rdf.schema;

import java.util.List;
import java.util.Iterator;

import com.hp.hpl.jena.ontology.Individual;

/**
 * Interface http://nlp2rdf.lod2.eu/schema/sso/Phrase
 */

public interface IPhrase extends Individual, eu.lod2.nlp2rdf.schema.str.IString {

	/**
	 * Domain property SubStringTrans
	 * with uri http://nlp2rdf.lod2.eu/schema/string/subStringTrans
	 */

	public boolean existsSubStringTrans();

	public boolean hasSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue);

	public int countSubStringTrans();

	public Iterator<eu.lod2.nlp2rdf.schema.str.String> iterateSubStringTrans();

	public List<eu.lod2.nlp2rdf.schema.str.String> listSubStringTrans();

	public void addSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue);

	public void addAllSubStringTrans(List<? extends eu.lod2.nlp2rdf.schema.str.IString> stringList);

	public void removeSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue);

	public void removeAllSubStringTrans();

	/**
	 * Domain property AnchorOf
	 * with uri http://nlp2rdf.lod2.eu/schema/string/anchorOf
	 */

	public boolean existsAnchorOf();

	public boolean hasAnchorOf(java.lang.String stringValue);

	public int countAnchorOf();

	public Iterator<java.lang.String> iterateAnchorOf();

	public List<java.lang.String> listAnchorOf();

	public void addAnchorOf(java.lang.String stringValue);

	public void addAllAnchorOf(List<java.lang.String> stringList);

	public void removeAnchorOf(java.lang.String stringValue);

	public void removeAllAnchorOf();

}