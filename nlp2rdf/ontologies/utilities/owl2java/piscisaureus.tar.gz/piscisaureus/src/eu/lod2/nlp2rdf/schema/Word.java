package eu.lod2.nlp2rdf.schema;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import nl.tudelft.tbm.eeni.owl2java.model.jenautils.NullFilter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.enhanced.BuiltinPersonalities;
import com.hp.hpl.jena.enhanced.EnhGraph;
import com.hp.hpl.jena.enhanced.EnhNode;
import com.hp.hpl.jena.enhanced.Implementation;
import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.Profile;
import com.hp.hpl.jena.ontology.impl.IndividualImpl;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.util.iterator.WrappedIterator;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import com.hp.hpl.jena.util.iterator.Filter;
import com.hp.hpl.jena.util.iterator.Map1;

// import interface
import eu.lod2.nlp2rdf.schema.IWord;

/**
 * Class http://nlp2rdf.lod2.eu/schema/sso/Word
 */
public class Word extends IndividualImpl implements IWord {

	private static Log log = LogFactory.getLog(Word.class);

	/**
	 * Implementation factory for Word
	 */
	static final public Implementation factory = new Implementation() {

		/**
		 * Convert a Node into an instance of the class
		 */
		public EnhNode wrap(Node n, EnhGraph eg) {
			if (canWrap(n, eg)) {
				return new Word(n, eg);
			} else {
				log.warn("Cannot convert node " + n.toString() + " to  Word");
				return null;
			}
		}

		/**
		 * Return true iff the node can be converted to an instance of
		 * this class (Word)
		 */
		public boolean canWrap(Node n, EnhGraph eg) {
			Profile profile;
			if (eg instanceof OntModel)
				profile = ((OntModel) eg).getProfile();
			else
				return false;

			if (!profile.isSupported(n, eg, Individual.class)) {
				return false;
			}

			Graph graph = eg.asGraph();
			return graph.contains(n, com.hp.hpl.jena.vocabulary.RDF.type.asNode(), eu.lod2.nlp2rdf.schema.tools.Vocabulary.Word.asNode());
		}
	};

	/**
	 * Filtering support for Word
	 */
	static final public Filter<Word> nullFilter = new NullFilter<Word>();

	/**
	 * Mapping support for Word
	 */
	public static <From> Map1<From, Word> mapperFrom(Class<From> from) {
		return new Map1<From, Word>() {
			@Override
			public Word map1(Object x) {
				if (x instanceof Statement) {
					Resource r = ((Statement) x).getResource();
					if (r.canAs(Word.class))
						return r.as(Word.class);
				} else if (x instanceof RDFNode) {
					if (((RDFNode) x).canAs(Word.class))
						return ((RDFNode) x).as(Word.class);
				}
				return null;
			}
		};
	}

	// Instantiate some mappers for general use
	static final public Map1<Statement, Word> statementMapper = mapperFrom(Statement.class);
	static final public Map1<Individual, Word> individualMapper = mapperFrom(Individual.class);
	static final public Map1<RDFNode, Word> nodeMapper = mapperFrom(RDFNode.class);

	/**
	 * Generic functions from parent class
	 */
	public Word(Node n, EnhGraph g) {
		super(n, g);
	}

	/**
	 * Registers all custom classes with jena
	 */
	public static void register() {
		log.debug("Registering custom class Word with jena");
		BuiltinPersonalities.model.add(Word.class, Word.factory);
		BuiltinPersonalities.model.add(eu.lod2.nlp2rdf.schema.Word.class, Word.factory);
	}

	/**
	 * Static Functions for instance handling
	 */
	public static Word get(java.lang.String uri, OntModel ontModel) {
		Individual individual = ontModel.getIndividual(uri);
		return (eu.lod2.nlp2rdf.schema.Word) individual.as(eu.lod2.nlp2rdf.schema.Word.class);
	}

	public static Word get(java.lang.String uri) {
		return get(uri, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Iterator<Word> iterate(OntModel ontModel) {
		ExtendedIterator<Individual> it = ontModel.listIndividuals(eu.lod2.nlp2rdf.schema.tools.Vocabulary.Word);
		return it.mapWith(individualMapper).filterDrop(nullFilter);
	}

	public static Iterator<Word> iterate() {
		return iterate(eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static List<Word> list(OntModel ontModel) {
		List<Word> list = new ArrayList<Word>();
		Iterator<Word> it = iterate(ontModel);
		while (it.hasNext()) {
			Word cls = it.next();
			list.add(cls);
		}
		return list;
	}

	public static List<Word> list() {
		return list(eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Iterator<Word> iterate(boolean direct, OntModel ontModel) {
		OntClass cls = ontModel.getOntClass("http://nlp2rdf.lod2.eu/schema/sso/Word");
		ExtendedIterator<? extends RDFNode> it = cls.listInstances(direct);
		ExtendedIterator<RDFNode> nodeIt = new WrappedIterator<RDFNode>(it) {
		};
		return nodeIt.mapWith(nodeMapper).filterDrop(nullFilter);
	}

	public static Iterator<Word> iterate(boolean direct) {
		return iterate(direct, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static List<Word> list(boolean direct, OntModel ontModel) {
		List<Word> list = new ArrayList<Word>();
		Iterator<Word> it = iterate(direct, ontModel);
		while (it.hasNext()) {
			Word cls = it.next();
			list.add(cls);
		}
		return list;
	}

	public static List<Word> list(boolean direct) {
		return list(direct, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static int count(OntModel ontModel) {
		int count = 0;
		Iterator<Word> it = iterate(ontModel);
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public static int count() {
		return count(eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static int count(boolean direct, OntModel ontModel) {
		int count = 0;
		Iterator<Word> it = iterate(direct, ontModel);
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public static int count(boolean direct) {
		return count(direct, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static boolean exists(java.lang.String uri, OntModel ontModel) {
		Individual individual = ontModel.getIndividual(uri);
		if (individual != null)
			return true;
		return false;
	}

	public static boolean exists(java.lang.String uri) {
		return exists(uri, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Word create(java.lang.String uri, OntModel ontModel) {
		return (Word) ontModel.createOntResource(Word.class, eu.lod2.nlp2rdf.schema.tools.Vocabulary.Word, uri);
	}

	public static Word create(OntModel ontModel) {
		return create(null, ontModel);
	}

	public static Word create(java.lang.String uri) {
		return create(uri, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Word create() {
		return create(null, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static void delete(java.lang.String uri, OntModel ontModel) {
		eu.lod2.nlp2rdf.schema.tools.Factory.deleteInstance(uri, ontModel);
	}

	public static void delete(java.lang.String uri) {
		eu.lod2.nlp2rdf.schema.tools.Factory.deleteInstance(uri);
	}

	/**
	 * Domain property sentence
	 * with uri http://nlp2rdf.lod2.eu/schema/sso/sentence
	 */
	public boolean existsSentence() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sentence);
	}

	public boolean hasSentence(eu.lod2.nlp2rdf.schema.ISentence sentenceValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sentence, sentenceValue);
	}

	public int countSentence() {
		int count = 0;
		Iterator<eu.lod2.nlp2rdf.schema.Sentence> it = iterateSentence();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<eu.lod2.nlp2rdf.schema.Sentence> iterateSentence() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sentence);
		return it.mapWith(eu.lod2.nlp2rdf.schema.Sentence.statementMapper).filterDrop(eu.lod2.nlp2rdf.schema.Sentence.nullFilter);
	}

	public List<eu.lod2.nlp2rdf.schema.Sentence> listSentence() {
		List<eu.lod2.nlp2rdf.schema.Sentence> list = new ArrayList<eu.lod2.nlp2rdf.schema.Sentence>();
		Iterator<eu.lod2.nlp2rdf.schema.Sentence> it = iterateSentence();
		while (it.hasNext()) {
			eu.lod2.nlp2rdf.schema.Sentence inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addSentence(eu.lod2.nlp2rdf.schema.ISentence sentenceValue) {
		addProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sentence, sentenceValue);
	}

	public void addAllSentence(List<? extends eu.lod2.nlp2rdf.schema.ISentence> sentenceList) {
		for (eu.lod2.nlp2rdf.schema.ISentence o : sentenceList)
			addSentence(o);

	}

	public void removeSentence(eu.lod2.nlp2rdf.schema.ISentence sentenceValue) {
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sentence, sentenceValue);
	}

	public void removeAllSentence() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sentence);
	}

	/**
	 * Domain property nextWordTrans
	 * with uri http://nlp2rdf.lod2.eu/schema/sso/nextWordTrans
	 */
	public boolean existsNextWordTrans() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.nextWordTrans);
	}

	public boolean hasNextWordTrans(eu.lod2.nlp2rdf.schema.IWord wordValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.nextWordTrans, wordValue);
	}

	public int countNextWordTrans() {
		int count = 0;
		Iterator<eu.lod2.nlp2rdf.schema.Word> it = iterateNextWordTrans();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<eu.lod2.nlp2rdf.schema.Word> iterateNextWordTrans() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.nextWordTrans);
		return it.mapWith(eu.lod2.nlp2rdf.schema.Word.statementMapper).filterDrop(eu.lod2.nlp2rdf.schema.Word.nullFilter);
	}

	public List<eu.lod2.nlp2rdf.schema.Word> listNextWordTrans() {
		List<eu.lod2.nlp2rdf.schema.Word> list = new ArrayList<eu.lod2.nlp2rdf.schema.Word>();
		Iterator<eu.lod2.nlp2rdf.schema.Word> it = iterateNextWordTrans();
		while (it.hasNext()) {
			eu.lod2.nlp2rdf.schema.Word inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addNextWordTrans(eu.lod2.nlp2rdf.schema.IWord wordValue) {
		addProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.nextWordTrans, wordValue);
	}

	public void addAllNextWordTrans(List<? extends eu.lod2.nlp2rdf.schema.IWord> wordList) {
		for (eu.lod2.nlp2rdf.schema.IWord o : wordList)
			addNextWordTrans(o);

	}

	public void removeNextWordTrans(eu.lod2.nlp2rdf.schema.IWord wordValue) {
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.nextWordTrans, wordValue);
	}

	public void removeAllNextWordTrans() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.nextWordTrans);
	}

	/**
	 * Domain property subStringTrans
	 * with uri http://nlp2rdf.lod2.eu/schema/string/subStringTrans
	 */
	public boolean existsSubStringTrans() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans);
	}

	public boolean hasSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans, stringValue);
	}

	public int countSubStringTrans() {
		int count = 0;
		Iterator<eu.lod2.nlp2rdf.schema.str.String> it = iterateSubStringTrans();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<eu.lod2.nlp2rdf.schema.str.String> iterateSubStringTrans() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans);
		return it.mapWith(eu.lod2.nlp2rdf.schema.str.String.statementMapper).filterDrop(eu.lod2.nlp2rdf.schema.str.String.nullFilter);
	}

	public List<eu.lod2.nlp2rdf.schema.str.String> listSubStringTrans() {
		List<eu.lod2.nlp2rdf.schema.str.String> list = new ArrayList<eu.lod2.nlp2rdf.schema.str.String>();
		Iterator<eu.lod2.nlp2rdf.schema.str.String> it = iterateSubStringTrans();
		while (it.hasNext()) {
			eu.lod2.nlp2rdf.schema.str.String inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue) {
		addProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans, stringValue);
	}

	public void addAllSubStringTrans(List<? extends eu.lod2.nlp2rdf.schema.str.IString> stringList) {
		for (eu.lod2.nlp2rdf.schema.str.IString o : stringList)
			addSubStringTrans(o);

	}

	public void removeSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue) {
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans, stringValue);
	}

	public void removeAllSubStringTrans() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans);
	}

	/**
	 * Domain property anchorOf
	 * with uri http://nlp2rdf.lod2.eu/schema/string/anchorOf
	 */
	public boolean existsAnchorOf() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);
	}

	public boolean hasAnchorOf(java.lang.String stringValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);
	}

	public int countAnchorOf() {
		int count = 0;
		Iterator<java.lang.String> it = iterateAnchorOf();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<java.lang.String> iterateAnchorOf() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);
		return it.mapWith(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.objectAsStringMapper).filterDrop(new NullFilter<java.lang.String>());
	}

	public List<java.lang.String> listAnchorOf() {
		List<java.lang.String> list = new ArrayList<java.lang.String>();
		Iterator<java.lang.String> it = iterateAnchorOf();
		while (it.hasNext()) {
			java.lang.String inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addAnchorOf(java.lang.String stringValue) {
		Literal literal = nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.createTypedLiteral((OntModel) getModel(), stringValue, "http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral");
		setPropertyValue(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf, literal);
	}

	public void addAllAnchorOf(List<java.lang.String> stringList) {
		for (java.lang.String o : stringList)
			addAnchorOf(o);
	}

	public void removeAnchorOf(java.lang.String stringValue) {
		Literal literal = nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.createTypedLiteral((OntModel) getModel(), stringValue, "http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral");
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf, literal);
	}

	public void removeAllAnchorOf() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);

	}

}
