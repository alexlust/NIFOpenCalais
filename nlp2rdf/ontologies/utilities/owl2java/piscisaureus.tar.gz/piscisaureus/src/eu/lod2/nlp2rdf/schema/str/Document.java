package eu.lod2.nlp2rdf.schema.str;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import nl.tudelft.tbm.eeni.owl2java.model.jenautils.NullFilter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.enhanced.BuiltinPersonalities;
import com.hp.hpl.jena.enhanced.EnhGraph;
import com.hp.hpl.jena.enhanced.EnhNode;
import com.hp.hpl.jena.enhanced.Implementation;
import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.Profile;
import com.hp.hpl.jena.ontology.impl.IndividualImpl;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.util.iterator.WrappedIterator;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import com.hp.hpl.jena.util.iterator.Filter;
import com.hp.hpl.jena.util.iterator.Map1;

// import interface
import eu.lod2.nlp2rdf.schema.str.IDocument;

/**
 * Class http://nlp2rdf.lod2.eu/schema/string/Document
 */
public class Document extends IndividualImpl implements IDocument {

	private static Log log = LogFactory.getLog(Document.class);

	/**
	 * Implementation factory for Document
	 */
	static final public Implementation factory = new Implementation() {

		/**
		 * Convert a Node into an instance of the class
		 */
		public EnhNode wrap(Node n, EnhGraph eg) {
			if (canWrap(n, eg)) {
				return new Document(n, eg);
			} else {
				log.warn("Cannot convert node " + n.toString() + " to  Document");
				return null;
			}
		}

		/**
		 * Return true iff the node can be converted to an instance of
		 * this class (Document)
		 */
		public boolean canWrap(Node n, EnhGraph eg) {
			Profile profile;
			if (eg instanceof OntModel)
				profile = ((OntModel) eg).getProfile();
			else
				return false;

			if (!profile.isSupported(n, eg, Individual.class)) {
				return false;
			}

			Graph graph = eg.asGraph();
			return graph.contains(n, com.hp.hpl.jena.vocabulary.RDF.type.asNode(), eu.lod2.nlp2rdf.schema.tools.Vocabulary.Document.asNode());
		}
	};

	/**
	 * Filtering support for Document
	 */
	static final public Filter<Document> nullFilter = new NullFilter<Document>();

	/**
	 * Mapping support for Document
	 */
	public static <From> Map1<From, Document> mapperFrom(Class<From> from) {
		return new Map1<From, Document>() {
			@Override
			public Document map1(Object x) {
				if (x instanceof Statement) {
					Resource r = ((Statement) x).getResource();
					if (r.canAs(Document.class))
						return r.as(Document.class);
				} else if (x instanceof RDFNode) {
					if (((RDFNode) x).canAs(Document.class))
						return ((RDFNode) x).as(Document.class);
				}
				return null;
			}
		};
	}

	// Instantiate some mappers for general use
	static final public Map1<Statement, Document> statementMapper = mapperFrom(Statement.class);
	static final public Map1<Individual, Document> individualMapper = mapperFrom(Individual.class);
	static final public Map1<RDFNode, Document> nodeMapper = mapperFrom(RDFNode.class);

	/**
	 * Generic functions from parent class
	 */
	public Document(Node n, EnhGraph g) {
		super(n, g);
	}

	/**
	 * Registers all custom classes with jena
	 */
	public static void register() {
		log.debug("Registering custom class Document with jena");
		BuiltinPersonalities.model.add(Document.class, Document.factory);
		BuiltinPersonalities.model.add(eu.lod2.nlp2rdf.schema.str.Document.class, Document.factory);
	}

	/**
	 * Static Functions for instance handling
	 */
	public static Document get(java.lang.String uri, OntModel ontModel) {
		Individual individual = ontModel.getIndividual(uri);
		return (eu.lod2.nlp2rdf.schema.str.Document) individual.as(eu.lod2.nlp2rdf.schema.str.Document.class);
	}

	public static Document get(java.lang.String uri) {
		return get(uri, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Iterator<Document> iterate(OntModel ontModel) {
		ExtendedIterator<Individual> it = ontModel.listIndividuals(eu.lod2.nlp2rdf.schema.tools.Vocabulary.Document);
		return it.mapWith(individualMapper).filterDrop(nullFilter);
	}

	public static Iterator<Document> iterate() {
		return iterate(eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static List<Document> list(OntModel ontModel) {
		List<Document> list = new ArrayList<Document>();
		Iterator<Document> it = iterate(ontModel);
		while (it.hasNext()) {
			Document cls = it.next();
			list.add(cls);
		}
		return list;
	}

	public static List<Document> list() {
		return list(eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Iterator<Document> iterate(boolean direct, OntModel ontModel) {
		OntClass cls = ontModel.getOntClass("http://nlp2rdf.lod2.eu/schema/string/Document");
		ExtendedIterator<? extends RDFNode> it = cls.listInstances(direct);
		ExtendedIterator<RDFNode> nodeIt = new WrappedIterator<RDFNode>(it) {
		};
		return nodeIt.mapWith(nodeMapper).filterDrop(nullFilter);
	}

	public static Iterator<Document> iterate(boolean direct) {
		return iterate(direct, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static List<Document> list(boolean direct, OntModel ontModel) {
		List<Document> list = new ArrayList<Document>();
		Iterator<Document> it = iterate(direct, ontModel);
		while (it.hasNext()) {
			Document cls = it.next();
			list.add(cls);
		}
		return list;
	}

	public static List<Document> list(boolean direct) {
		return list(direct, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static int count(OntModel ontModel) {
		int count = 0;
		Iterator<Document> it = iterate(ontModel);
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public static int count() {
		return count(eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static int count(boolean direct, OntModel ontModel) {
		int count = 0;
		Iterator<Document> it = iterate(direct, ontModel);
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public static int count(boolean direct) {
		return count(direct, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static boolean exists(java.lang.String uri, OntModel ontModel) {
		Individual individual = ontModel.getIndividual(uri);
		if (individual != null)
			return true;
		return false;
	}

	public static boolean exists(java.lang.String uri) {
		return exists(uri, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Document create(java.lang.String uri, OntModel ontModel) {
		return (Document) ontModel.createOntResource(Document.class, eu.lod2.nlp2rdf.schema.tools.Vocabulary.Document, uri);
	}

	public static Document create(OntModel ontModel) {
		return create(null, ontModel);
	}

	public static Document create(java.lang.String uri) {
		return create(uri, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static Document create() {
		return create(null, eu.lod2.nlp2rdf.schema.tools.Factory.getDefaultModel());
	}

	public static void delete(java.lang.String uri, OntModel ontModel) {
		eu.lod2.nlp2rdf.schema.tools.Factory.deleteInstance(uri, ontModel);
	}

	public static void delete(java.lang.String uri) {
		eu.lod2.nlp2rdf.schema.tools.Factory.deleteInstance(uri);
	}

	/**
	 * Domain property sourceUrl
	 * with uri http://nlp2rdf.lod2.eu/schema/string/sourceUrl
	 */
	public boolean existsSourceUrl() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceUrl);
	}

	public boolean hasSourceUrl(eu.lod2.nlp2rdf.schema.IThing thingValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceUrl, thingValue);
	}

	public int countSourceUrl() {
		int count = 0;
		Iterator<eu.lod2.nlp2rdf.schema.Thing> it = iterateSourceUrl();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<eu.lod2.nlp2rdf.schema.Thing> iterateSourceUrl() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceUrl);
		return it.mapWith(eu.lod2.nlp2rdf.schema.Thing.statementMapper).filterDrop(eu.lod2.nlp2rdf.schema.Thing.nullFilter);
	}

	public List<eu.lod2.nlp2rdf.schema.Thing> listSourceUrl() {
		List<eu.lod2.nlp2rdf.schema.Thing> list = new ArrayList<eu.lod2.nlp2rdf.schema.Thing>();
		Iterator<eu.lod2.nlp2rdf.schema.Thing> it = iterateSourceUrl();
		while (it.hasNext()) {
			eu.lod2.nlp2rdf.schema.Thing inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addSourceUrl(eu.lod2.nlp2rdf.schema.IThing thingValue) {
		addProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceUrl, thingValue);
	}

	public void addAllSourceUrl(List<? extends eu.lod2.nlp2rdf.schema.IThing> thingList) {
		for (eu.lod2.nlp2rdf.schema.IThing o : thingList)
			addSourceUrl(o);

	}

	public void removeSourceUrl(eu.lod2.nlp2rdf.schema.IThing thingValue) {
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceUrl, thingValue);
	}

	public void removeAllSourceUrl() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceUrl);
	}

	/**
	 * Domain property sourceString
	 * with uri http://nlp2rdf.lod2.eu/schema/string/sourceString
	 */
	public boolean existsSourceString() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceString);
	}

	public boolean hasSourceString(java.lang.String stringValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceString);
	}

	public int countSourceString() {
		int count = 0;
		Iterator<java.lang.String> it = iterateSourceString();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<java.lang.String> iterateSourceString() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceString);
		return it.mapWith(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.objectAsStringMapper).filterDrop(new NullFilter<java.lang.String>());
	}

	public List<java.lang.String> listSourceString() {
		List<java.lang.String> list = new ArrayList<java.lang.String>();
		Iterator<java.lang.String> it = iterateSourceString();
		while (it.hasNext()) {
			java.lang.String inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addSourceString(java.lang.String stringValue) {
		Literal literal = nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.createTypedLiteral((OntModel) getModel(), stringValue, "http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral");
		setPropertyValue(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceString, literal);
	}

	public void addAllSourceString(List<java.lang.String> stringList) {
		for (java.lang.String o : stringList)
			addSourceString(o);
	}

	public void removeSourceString(java.lang.String stringValue) {
		Literal literal = nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.createTypedLiteral((OntModel) getModel(), stringValue, "http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral");
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceString, literal);
	}

	public void removeAllSourceString() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.sourceString);

	}

	/**
	 * Domain property subStringTrans
	 * with uri http://nlp2rdf.lod2.eu/schema/string/subStringTrans
	 */
	public boolean existsSubStringTrans() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans);
	}

	public boolean hasSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans, stringValue);
	}

	public int countSubStringTrans() {
		int count = 0;
		Iterator<eu.lod2.nlp2rdf.schema.str.String> it = iterateSubStringTrans();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<eu.lod2.nlp2rdf.schema.str.String> iterateSubStringTrans() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans);
		return it.mapWith(eu.lod2.nlp2rdf.schema.str.String.statementMapper).filterDrop(eu.lod2.nlp2rdf.schema.str.String.nullFilter);
	}

	public List<eu.lod2.nlp2rdf.schema.str.String> listSubStringTrans() {
		List<eu.lod2.nlp2rdf.schema.str.String> list = new ArrayList<eu.lod2.nlp2rdf.schema.str.String>();
		Iterator<eu.lod2.nlp2rdf.schema.str.String> it = iterateSubStringTrans();
		while (it.hasNext()) {
			eu.lod2.nlp2rdf.schema.str.String inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue) {
		addProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans, stringValue);
	}

	public void addAllSubStringTrans(List<? extends eu.lod2.nlp2rdf.schema.str.IString> stringList) {
		for (eu.lod2.nlp2rdf.schema.str.IString o : stringList)
			addSubStringTrans(o);

	}

	public void removeSubStringTrans(eu.lod2.nlp2rdf.schema.str.IString stringValue) {
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans, stringValue);
	}

	public void removeAllSubStringTrans() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.subStringTrans);
	}

	/**
	 * Domain property anchorOf
	 * with uri http://nlp2rdf.lod2.eu/schema/string/anchorOf
	 */
	public boolean existsAnchorOf() {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);
	}

	public boolean hasAnchorOf(java.lang.String stringValue) {
		return hasProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);
	}

	public int countAnchorOf() {
		int count = 0;
		Iterator<java.lang.String> it = iterateAnchorOf();
		while (it.hasNext()) {
			it.next();
			count++;
		}
		return count;
	}

	public Iterator<java.lang.String> iterateAnchorOf() {
		ExtendedIterator<Statement> it = listProperties(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);
		return it.mapWith(nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.objectAsStringMapper).filterDrop(new NullFilter<java.lang.String>());
	}

	public List<java.lang.String> listAnchorOf() {
		List<java.lang.String> list = new ArrayList<java.lang.String>();
		Iterator<java.lang.String> it = iterateAnchorOf();
		while (it.hasNext()) {
			java.lang.String inst = it.next();
			list.add(inst);
		}
		return list;
	}

	public void addAnchorOf(java.lang.String stringValue) {
		Literal literal = nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.createTypedLiteral((OntModel) getModel(), stringValue, "http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral");
		setPropertyValue(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf, literal);
	}

	public void addAllAnchorOf(List<java.lang.String> stringList) {
		for (java.lang.String o : stringList)
			addAnchorOf(o);
	}

	public void removeAnchorOf(java.lang.String stringValue) {
		Literal literal = nl.tudelft.tbm.eeni.owl2java.model.xsd.XsdUtils.createTypedLiteral((OntModel) getModel(), stringValue, "http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral");
		removeProperty(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf, literal);
	}

	public void removeAllAnchorOf() {
		removeAll(eu.lod2.nlp2rdf.schema.tools.Vocabulary.anchorOf);

	}

}
