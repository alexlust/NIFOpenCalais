package eu.lod2.nlp2rdf.schema;

import java.util.List;
import java.util.Iterator;

import com.hp.hpl.jena.ontology.Individual;

/**
 * Interface http://www.w3.org/2002/07/owl#Thing
 */

public interface IThing extends Individual {

}