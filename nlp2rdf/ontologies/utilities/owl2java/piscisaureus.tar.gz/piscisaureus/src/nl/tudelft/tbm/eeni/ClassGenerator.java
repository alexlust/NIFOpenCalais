package nl.tudelft.tbm.eeni;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import nl.tudelft.tbm.eeni.owl2java.JenaGenerator;
import nl.tudelft.tbm.eeni.owlstructure.processor.PropertyRangeSimplifier;
import nl.tudelft.tbm.eeni.owlstructure.utils.OntologyUtils;

/**
 * User: Sebastian Hellmann - http://bis.informatik.uni-leipzig.de/SebastianHellmann
 */
class ClassGenerator {
    public static void main(String[] args) {
        try {
            // Load ontology, use Jena or a shorcut like this
            OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_DL_MEM, ModelFactory.createDefaultModel());
            ontModel.read("http://nlp2rdf.lod2.eu/schema/sso/");


            // Simplify the definition of property ranges
            // This is necessary because Owl2Java chokes on complex range
            // definitions (i.e. those containing anonymous classes)
            (new PropertyRangeSimplifier()).process(ontModel);

            // Generate classes that provide access to ontology instances
            JenaGenerator generator = new JenaGenerator();
            generator.generate(ontModel, "src", "eu.lod2.nlp2rdf.schema");

        } catch (Exception e) {
           e.printStackTrace();
        }
    }
}
