package nl.tudelft.tbm.eeni.owl2java.utils;

public interface IReporting {

	String getJModelReport();
}
