package nl.tudelft.tbm.eeni.owl2java.exceptions;

public class CarindinalityException extends Owl2JavaException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5773542543583470274L;

}
