package nl.tudelft.tbm.eeni.owl2java.utils;

public interface IStatistics {
	
	public String getStatistics();

}
